package virtual_pet;


public class VirtualPet {

//    Pet Statuses
    public int food = 25; //Hunger
    public  int watr = 25; //Water
    public int bore = 25; //Boredom
    public int ener = 25; //Tiredness

    //Functions to change level of Statuses
    public void tickFeed(){
        food += 15;
        watr -= 10;
        bore -= 5;
    }
    public void tickThirst(){
        watr += 15;
        food -= 10;
        bore -= 5;
    }
    public void tickBoredom(){
        bore += 15;
        ener -= 10;
        food -= 5;
        watr -= 5;

    }
    public void tickEnergy(){
        ener += 15;
        bore -= 10;
        food -= 5;
        watr -= 5;

    }

    //Used to Display the update Status of Pet.
    public String statusDisplay(){
        return ("Hunger " + food + " \nThirst " + watr + " \nBoredom "
                + bore + " \nEnergy " + ener + "\n");
    }
}

