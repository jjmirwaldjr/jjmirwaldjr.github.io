package virtual_pet;

import java.util.Scanner;
public class VirtualPetApplication {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        VirtualPet status = new VirtualPet();

        System.out.println("Hello, i'm your new Virtual Friend.");
        System.out.println("Would you like to start taking care of me?");
        String response = input.nextLine();

        while (response.equals("yes")) {
            System.out.println("Cool, thank you for taking care of me!.");
            System.out.println("here is how I currently am! \n");

            System.out.println("Here is how hungry i am " + status.food);
            System.out.println("Here is how thirsty i am " + status.watr);
            System.out.println("Here is how bored I am " + status.bore);
            System.out.println("here is how sleepy I am " + status.ener);
            System.out.println("\nPlease type menu to continue.");
            response = input.nextLine();
        } while (!response.equals("6")) {

            System.out.println("Please select from the menu below.");
            System.out.println("Press 1 to Feed");
            System.out.println("Press 2 to drink");
            System.out.println("Press 3 to play");
            System.out.println("Press 4 sleep");
            System.out.println("Press 5 Check Status's");
            System.out.println("Press 6 to Exit" + "\n");
            String selectedOption = input.next();
            switch (selectedOption){
                case "1":
                    System.out.println("Yummy, thank you for the food.");
                    status.tickFeed();
                    System.out.println(status.statusDisplay() + "\n");
                    break;
                case "2":
                    System.out.println("Delicious, thank you for the water.");
                    status.tickThirst();
                    System.out.println(status.statusDisplay() + "\n");
                    break;
                case "3":
                    System.out.println("That was fun, lets do it again!");
                    status.tickBoredom();
                    System.out.println(status.statusDisplay() + "\n");
                    break;
                case "4":
                    System.out.println("Yawn, goodnight.");
                    status.tickEnergy();
                    System.out.println(status.statusDisplay() + "\n");
                    break;
                case "5" :
                    System.out.println("Here is how i am Feeling.");
                    System.out.println(status.statusDisplay() + "\n");
            } if (selectedOption.equals("6")){
                break;
            }
        }
    }
}

