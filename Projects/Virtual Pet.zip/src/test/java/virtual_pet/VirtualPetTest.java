package virtual_pet;

import java.util.Scanner;

public class VirtualPetTest {
    public static void main(String[] args) {
        //Interact with a VirtualPet object in this method, NOTE: works
        Scanner input = new Scanner(System.in);
        VirtualPet status = new VirtualPet();


        System.out.println("Hello, i'm your new Virtual Friend.");
        System.out.println("Would you like to start taking care of me?");

        String response = input.nextLine();

        // this is the intro, NOTE: works

        while (response.equals("yes")) {
            System.out.println("Cool, thank you for taking care of me!.");
            System.out.println("here is how I currently am! \n");
            //Virtual pets Status NOTE: works
            System.out.println("Here is how hungry I am: " + status.food);
            System.out.println("Here is how thirsty I am: " + status.watr);
            System.out.println("Here is how bored I am: " + status.bore);
            System.out.println("here is how tired I am: " + status.ener);
            System.out.println("\nPlease type menu to continue.");
            response = input.nextLine();
        } if (response.equals("no")){
            System.out.println("See you again Soon thanks for Nothing.");
        }
        while (response.equals("menu")) {
            //menu options, NOTE: Works
            System.out.println("Please select from the menu below.");
            System.out.println("Press 1 to Feed");
            System.out.println("Press 2 to drink");
            System.out.println("Press 3 to play");
            System.out.println("Press 4 sleep");
            System.out.println("Press 5 to check how I am doing");
            System.out.println("Press 6 close game");
            String selectedOption = input.next();
//            The menu itself, NOTE: menu works; add the status's and finish the menu.
            switch (selectedOption){
                case "1":
                    System.out.println("Yummy, thank you for the food.");
                    status.tickFeed();
                    System.out.println(status.statusDisplay());
                    break;
                case "2":
                    System.out.println("Delicious, thank you for the water.");
                    status.tickThirst();
                    System.out.println(status.statusDisplay());
                    break;
                case "3":
                    System.out.println("That was fun, lets do it again!");
                    status.tickBoredom();
                    System.out.println(status.statusDisplay());
                    break;
                case "4":
                    System.out.println("Yawn, goodnight.");
                    status.tickEnergy();
                    System.out.println(status.statusDisplay());
                    break;
                case "5":
                    System.out.println("here is how I'm doing!");
                    System.out.println(status.statusDisplay());
                    break;
            } if (selectedOption.equals("6")){
                System.out.println("Thank you for Playing!");
                break;
            }


        }


    }
}

