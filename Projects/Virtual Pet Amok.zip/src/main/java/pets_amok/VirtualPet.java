package pets_amok;

//This class handles the different levels of the different pets
//Organic dogs and Robotic Cats.

public abstract class VirtualPet {

    protected int happinessLevel;
    protected int healthLevel;
    protected int exerciseLevel;

    public VirtualPet(int healthLevel, int exerciseLevel, int happinessLevel) {
        this.healthLevel = healthLevel;
        this.exerciseLevel = exerciseLevel;
        this.happinessLevel = happinessLevel;
    }


    //Getters
//    public int getHealthLevel() {
//        return healthLevel;
//    }
//    public int getExerciseLevel() {
//        return exerciseLevel;
//    }
//    public int getHappinessLevel() {
//        return happinessLevel;
//    }

//    public void decreasesHealthLevel(int decreasesHealthLevel) {
//        healthLevel -= decreasesHealthLevel;
//    }
//
//    public void increaseWasteLevel(int increasesWasteLevel) {
//        wasteLevel += increasesWasteLevel;
//    }
//
//
//    public void decreaseExerciseLevel(int walkingTheAnimals) {
//        exerciseLevel += walkingTheAnimals;
//    }
//
//    public void decreasesNourishmentLevel(int getsHungryAndThirsty) {
//        nourishmentLevel = getsHungryAndThirsty;
//    }
//
//    public void increaseOilLevel(int oilLevelForRoboCats) {
//        oilLevel += oilLevelForRoboCats;
//    }


}
