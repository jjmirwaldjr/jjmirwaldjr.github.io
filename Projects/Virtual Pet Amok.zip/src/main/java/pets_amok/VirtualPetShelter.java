package pets_amok;

public class VirtualPetShelter {

    RoboticCats theCats = new RoboticCats();
    OrganicDogs theDogs = new OrganicDogs();

    //The Kennel.
    //WATCH THE CATS.
    public void getTheDogs() {
        System.out.println("Health:" + theDogs.healthLevel + ", Exercise Level:" + theDogs.exerciseLevel +
                ", The happiness of the Kennel: " + theDogs.happinessLevel
                + ", Filth: " + theDogs.getWasteLevel() + ", Food & water: " + theDogs.getNourishmentLevel());
    }

    public void getTheCats() {
        System.out.println("Battery:" + theCats.healthLevel + ", Exercise Level:" + theCats.exerciseLevel +
                ", The happiness of the Kennel: " + theCats.happinessLevel
                + ", Oil Level: " + theCats.getOilLevel());
    }

    //methods to modify the Values
    public void cleanCages() {
        theDogs.wasteLevel -= 10;
        theDogs.healthLevel += 15;
        theDogs.happinessLevel += 5;
    }

    public void walkThePets() {
        theDogs.healthLevel += 10;
        theDogs.exerciseLevel += 10;
        theDogs.happinessLevel += 5;

        theCats.healthLevel -= 5;
        theCats.exerciseLevel += 5;
        theCats.happinessLevel += 5;
    }

    public void giveNourishmentToDogs() {
        theDogs.healthLevel += 15;
        theDogs.nourishmentLevel += 10;
        theDogs.wasteLevel += 5;
        theDogs.happinessLevel += 5;
    }

    public void oilTheCats() {
        theCats.oilLevel += 10;
        theCats.healthLevel += 10;
        theCats.happinessLevel += 5;
    }
}
