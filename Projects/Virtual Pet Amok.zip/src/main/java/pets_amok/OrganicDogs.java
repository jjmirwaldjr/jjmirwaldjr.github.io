package pets_amok;

//This class is the Organic Dogs
//ALL DOGS ARE FRIENDS

public class OrganicDogs extends VirtualPet {

    public int wasteLevel;
    public int nourishmentLevel;

    public OrganicDogs() {
        super(60, 20, 40);
        wasteLevel = 30;
        nourishmentLevel = 40;
    }

    //Getters
    public int getWasteLevel() {
        return wasteLevel;
    }

    public int getNourishmentLevel() {
        return nourishmentLevel;
    }


//    public void decreaseHealthLevel(VirtualPet myPet) {
//        myPet.decreasesHealthLevel(20);
//    }
//
//    public void increaseWasteLevel(VirtualPet myPet) {
//        myPet.increaseWasteLevel(20);
//    }
//
//    public void increaseExerciseLevel(VirtualPet myPet) {
//        myPet.decreaseExerciseLevel(10);
//    }
//
//    public void decreaseNourishmentLevel(VirtualPet myPet) {
//        myPet.decreasesNourishmentLevel(15);
//    }
}
