package pets_amok;

import java.util.Scanner;

public class Application {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        VirtualPetShelter thePets = new VirtualPetShelter();

        String userChoice;

        do {
            System.out.println("Hello and welcome to my shelter.");
            System.out.println("As you can see we have a new type of pet we are testing.");
            System.out.println("They are un-creatively called Robotic Cats.");
            System.out.println("Side note, they are just as evil as real cats, so watch your self.");
            System.out.println("I swore i heard one say he will take over the world.\n");

            //Kennel for the Organic Dogs
            System.out.println("Dogs");
            thePets.getTheDogs();
            System.out.println();
            //Kennel for the Robotic Cats
            System.out.println("Robotic Cats");
            thePets.getTheCats();
            System.out.println();
            //Menu
            System.out.println("What would you like to do?");
            System.out.println("Press 1 to Clean the Cages");
            System.out.println("Press 2 to take the pets for a walk (watch the cats, they are evil)");
            System.out.println("Press 3 to feed the dogs");
            System.out.println("Press 4 to recharge the evil robotic Cats");
            System.out.println("Press 5 to leave ths Shelter");


            userChoice = input.nextLine();

            switch (userChoice) {
                case "1":
                    thePets.cleanCages();
                    System.out.println("you have clean the Cages \n");
                    break;
                case "2":
                    thePets.walkThePets();
                    System.out.println("You have taken the dogs for a walk.");
                    System.out.println("while you was gone, the cats have moved across the room.\n");
                    break;
                case "3":
                    thePets.giveNourishmentToDogs();
                    System.out.println("You have feed and watered the dogs, they are very happy\n");
                    break;
                case "4":
                    thePets.oilTheCats();
                    System.out.println("You have Oiled the cats joints.");
                    System.out.println("they can now move into the sun to recharge.");
                    System.out.println("you swear you hear one of them call you there servant.\n");

            }
        } while (!userChoice.equals("5"));

    }
}
