package pets_amok;

//this is for the robotic cats, I think they are evil. need to watch them.

public class RoboticCats extends VirtualPet {

    public int oilLevel;

    public RoboticCats() {
        super(40, 20, 25);
        oilLevel = 20;
    }

    //Getters
    public int getOilLevel() {
        return oilLevel;
    }


//    public void decreaseHealthLevel(VirtualPet myPets) {
//        myPets.decreasesHealthLevel(15);
//    }
//
//    public void decreaseExerciseLevel(VirtualPet myPets) {
//        myPets.decreaseExerciseLevel(-15);
//    }
//
//
//    public void increaseOilLevel(VirtualPet myPets) {
//        myPets.increaseOilLevel(25);
//    }
}
