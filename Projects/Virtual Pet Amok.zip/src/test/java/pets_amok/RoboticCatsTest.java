package pets_amok;

public class RoboticCatsTest {
//
//    RoboticCats roboCats = new RoboticCats(100, 50, 20);
//    VirtualPet myPets = new VirtualPet();
//
//    @Test
//    public void shouldDecreaseHealthLevelFrom100To85() {
//        roboCats.decreaseHealthLevel(myPets);
//        int decreaseHealthLevel = myPets.getHealthLevel();
//        assertEquals(85, decreaseHealthLevel);
//    }
//
//    @Test
//    public void shouldDecreaseExerciseLevelFrom50To35() {
//        roboCats.decreaseExerciseLevel(myPets);
//        int decreasesExerciseLevel = myPets.getExerciseLevel();
//        assertEquals(35, decreasesExerciseLevel);
//    }
//
//    @Test
//    public void shouldIncreaseOilLevelFrom25To50() {
//        roboCats.increaseOilLevel(myPets);
//        int increaseOilLevel = myPets.getOilLevel();
//        assertEquals(50, increaseOilLevel);
//    }
//
//    @Test
//    public void shouldDecreaseHealthLevelAndDecreaseEnergyLevel() {
//        roboCats.decreaseHealthLevel(myPets);
//        roboCats.decreaseExerciseLevel(myPets);
//        int decreaseHealthLevel = myPets.getHealthLevel();
//        int decreasesExerciseLevel = myPets.getExerciseLevel();
//        assertEquals(85, decreaseHealthLevel);
//        assertEquals(35, decreasesExerciseLevel);
//    }
}
