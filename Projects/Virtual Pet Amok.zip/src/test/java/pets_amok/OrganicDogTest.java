package pets_amok;

public class OrganicDogTest {
//
//    OrganicDogs orgDogs = new OrganicDogs(100, 50, 20, 50);
//    VirtualPet myPet = new VirtualPet();
//
//    @Test
//    public void shouldDecreaseHealthLevelFrom100To80() {
//        orgDogs.decreaseHealthLevel(myPet);
//        int dogsHealthLevel = myPet.getHealthLevel();
//        assertEquals(80, dogsHealthLevel);
//    }
//
//    @Test
//    public void shouldIncreaseWasteLevelFrom20To40() {
//        orgDogs.increaseWasteLevel(myPet);
//        int dogsWasteLevel = myPet.getWasteLevel();
//        assertEquals(40, dogsWasteLevel);
//    }
//
//    @Test
//    public void shouldIncreaseExerciseFrom50To60() {
//        orgDogs.increaseExerciseLevel(myPet);
//        int walkingTheDogs = myPet.getExerciseLevel();
//        assertEquals(60, walkingTheDogs);
//    }
//
//    @Test
//    public void shouldDecreaseNourishmentFrom50To15() {
//        orgDogs.decreaseNourishmentLevel(myPet);
//        int feedingAndWateringDogs = myPet.getNourishmentLevel();
//        assertEquals(15, feedingAndWateringDogs);
//    }
//
//    @Test
//    public void shouldDecreaseHealthLevelWhileIncreasingWasteLevel() {
//        orgDogs.increaseWasteLevel(myPet);
//        orgDogs.decreaseHealthLevel(myPet);
//        int getHealth = myPet.getHealthLevel();
//        int getWaste = myPet.getWasteLevel();
//        assertEquals(80, getHealth);
//        assertEquals(40, getWaste);
//    }
}
