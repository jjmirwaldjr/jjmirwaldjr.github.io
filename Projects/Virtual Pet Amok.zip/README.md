# Virtual Pets Amok

### Amok Version 0.2

- added The Organic Pet, Finished Testing

### Amok Version 0.4

- added Robotic Pet, Finished Testing
- added one super class and an instance

### Amok Version 0.6

- Modified code by taking out some redundant methods

### Amok Version 0.75

- added VP shelter Class
- built HashMap

### Amok Version 1.0

- Finished the UI
- added modifiers to manipulate the variables

### Goals

- ~~Add the robotic Pet~~
- ~~finish testing all pets~~
- ~~Work on making sure the health value is modified by a variety of factors~~
- ~~Build the APP and finish testing its functions.~~