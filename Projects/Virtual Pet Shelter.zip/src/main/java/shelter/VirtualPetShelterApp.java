package shelter;

//This is the User Interface (UI).

import java.util.Scanner;

public class VirtualPetShelterApp {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        VirtualPetShelter myPet = new VirtualPetShelter();

        VirtualPet pet1 = new VirtualPet("Frankie", Math.random() * 51,
                Math.random() * 51, Math.random() * 51);

        VirtualPet pet2 = new VirtualPet("Rosie", Math.random() * 51,
                Math.random() * 51, Math.random() * 51);

        myPet.add(pet1);
        myPet.add(pet2);

        String userChoice = "";

        do {
            System.out.println("Welcome to the Virtual Pet Shelter.");
            System.out.println("Thies are the pets that are currently in the Shelter.\n");
            myPet.showPets();

            System.out.println("What would you like to do?");
            System.out.println("Choose an Option\n");
            System.out.println("Press 1 to feed pets.");
            System.out.println("Press 2 to give water to pets.");
            System.out.println("Press 3 to play with a pet.");
            System.out.println("Press 4 to adopt a pet.");
            System.out.println("Press 5 to rescue a pet.");
            System.out.println("Press 6 to leave the shelter.");
            userChoice = input.nextLine();

            if (userChoice.equals("1")) {
                System.out.println("Enter the name of the pet you want to feed");
               myPet.feedAll();
                System.out.println("Thank you for the food.\n");
            } else if (userChoice.equals("2")) {
                System.out.println("Enter the name of the pet you would like to give water too.");
                myPet.waterAll();
                System.out.println("Thank you for the water.\n");
            } else if (userChoice.equals("3")) {
                System.out.println("Enter the name of the pet you would like to play with.");
                String petName = input.nextLine();
                System.out.println("how long would you like to play with them.");
                int playAmt = input.nextInt();
                myPet.playWithPet(petName, playAmt);
                System.out.println("Thank you for playing with me!");
            } else if (userChoice.equals("4")) {
                System.out.println("You have a Person ready to adopt a Pet.");
                System.out.println("Please enter the name of the pet that is ready for adoption.");
                String petName = input.nextLine();
                myPet.adopt(petName);
            } else if (userChoice.equals("5")) {
                System.out.println("You found a Animal on the Street, please enter the name for the rescue.");
                String petName = input.nextLine();
                myPet.add(new VirtualPet(petName, Math.random() * 51, Math.random() * 51,
                        Math.random() * 51));
            }
        } while (!userChoice.equals("6"));
        System.out.println("Thank you for working at the Shelter");
        System.out.println("Have a nice day.");

    }
}

