package shelter;

// This is the Pet itself.
// This is where the status are modified.
// Below is the functions to modify the pets Statuses.

public class VirtualPet {

    private String petName;
    private int hunger;
    private int thirst;
    private int boredom;

    public VirtualPet(String petName, double hunger, double thirst, double boredom) {
        this.petName = petName;
        this.hunger = (int) hunger;
        this.thirst = (int) thirst;
        this.boredom = (int) boredom;
    }


    // This gets an assigned name of the pet
    public String getPetName() {
        return petName;
    }
    // This collects the hunger status
    public int getHunger(){
        return hunger;
    }
    // This collects the Thirst status
    public int getThirst(){
        return thirst;
    }
    // This collects the Boredom status
    public int getBoredom(){
        return boredom;
    }
    // This feeds the pet
//    public void feedPet(int amountToFeed) {hunger += amountToFeed;}
    public void tickFeedPet(){
        hunger += 10;
        thirst -= 5;
        boredom -= 5;
    }
    // This gives the pet water
//    public void waterPet(int amountToWater) {thirst += amountToWater;}
    public void tickWaterPet(){
        thirst += 10;
        hunger -= 5;
        boredom -= 5;
    }
    // This lets you play with a pet
    public void playWithAPet(int amountToPlay) {boredom += amountToPlay;}
}
