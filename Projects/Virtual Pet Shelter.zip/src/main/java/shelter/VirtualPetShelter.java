package shelter;

// This is the pet Shelter Class.
// This class is where the pets are sheltered.

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class VirtualPetShelter {

    Map<String, VirtualPet> myPet = new HashMap<>();

    // This adds a pet to the array.
    public void add(VirtualPet petToAdd) {
        myPet.put(petToAdd.getPetName(), petToAdd);
    }

    // This finds a pet in the array.
    public VirtualPet findPet(String petName) {
        return myPet.get(petName);
    }

    // This gets all the pets in the array.
    public Collection<VirtualPet> getAllPets() {
        return myPet.values();
    }

    //This removes the pet from the array.
    public void adopt(String adoptPet) {
        myPet.remove(adoptPet);
    }

    // This runs the feedPet function in the VirtualPet Class
//    public void feedPet(String petName, int amountToFeed) {
//        VirtualPet amountToFeedAPet = findPet(petName);
//        amountToFeedAPet.feedPet(amountToFeed);
//    }

    public void feedAll(){
        for (VirtualPet pets : myPet.values()) {
            pets.tickFeedPet();
        }
    }

    // This runs the waterPet function in the VirtualPet Class
    public void waterAll(){
        for (VirtualPet pets : myPet.values()) {
            pets.tickWaterPet();
        }
    }

    // This runs the playWithAPet function in the VirtualPet Class
    public void playWithPet(String petName, int amountToPlay) {
        VirtualPet amountToPlayWithPet = findPet(petName);
        amountToPlayWithPet.playWithAPet(amountToPlay);
    }

    // This shows the pets in the shelter.
    public void showPets() {
        for (VirtualPet pets : myPet.values()) {
            System.out.println("Pets Name: " + pets.getPetName() + "\n" + "Statuses |" + " Hunger: " + pets.getHunger() + " Thirst: " + pets.getThirst()
                    + " Boredom: " + pets.getBoredom() + "|\n");
        }
    }
}
