package shelter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Collection;


import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class VirtualPetShelterTest{


    VirtualPetShelter underTest;
    VirtualPet pet1;
    VirtualPet pet2;

    @BeforeEach
    public void setUp(){
        underTest = new VirtualPetShelter();
        pet1 = new VirtualPet("Frankie", 25, 25,
                25);
        pet2 = new VirtualPet("Rosie", 25, 25,
                25);

    }

    @Test
    public void shouldAddAPet(){
        underTest.add(pet1);
        VirtualPet pet = underTest.findPet("Frankie");
        assertEquals(pet,pet1);
    }

    @Test
    public void shouldAddTwoPets(){
        underTest.add(pet1);
        underTest.add(pet2);
        Collection<VirtualPet> allPets = underTest.getAllPets();
        assertThat(allPets, containsInAnyOrder(pet2,pet1));
    }

    @Test
    public void shouldAdoptThePet(){
        underTest.add(pet1);
        underTest.adopt(pet1);
        VirtualPet pet = underTest.findPet("Frankie");
        assertNull(pet);
    }

    @Test
    public void shouldModifyThePetStatus(){
        underTest.add(pet1);
        underTest.feedPet(pet1.getPetName(), 5);
        assertEquals(pet1.getHunger(), 30);
    }

    @Test
    public void shouldGIveWaterToPet(){
        underTest.add(pet1);
        underTest.waterPet(pet1.getPetName(), 5);
        assertEquals(pet1.getThirst(), 30);
    }

    @Test
    public void shouldPlayWithAPet(){
        underTest.add(pet1);
        underTest.playWithPet(pet1.getPetName(), 5);
        assertEquals(pet1.getBoredom(), 30);
    }

}