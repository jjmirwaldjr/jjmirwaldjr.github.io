# Virtual Pet Shelter

### Pet Shelter v 0.2

- added test functions, for two pets
- added adoption function.

### Pets Shelter v 0.4

- Finished Test functions

### Pets Shelter v 0.6

- Started working on UI

### Pets Shelter v 0.8

- Added the three main functions, Feed; Water; and Play
- Working on last two functions, Adopt; and Rescue

### Pets Shelter v 1.0

- Finished all required functions
- Created a basic UI

### Pets Shelter V1.1

- Finished modifying the Feed/Water fuction to feed & water the pets.

### goals

- ~~Finish test functions~~
- ~~Add the status modifiers.~~
- ~~Work on UI options~~
- ~~Finish UI options~~
- Optional: Touch up the UI

